package com.example.lab11;

public record Number(int num) {}